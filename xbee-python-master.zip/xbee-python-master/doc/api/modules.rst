API reference
=============

Following is API reference material on major parts of XBee Python library.

.. toctree::
   :maxdepth: 5

   digi
