digi\.xbee\.models\.message module
==================================

.. automodule:: digi.xbee.models.message
    :members:
    :inherited-members:
    :show-inheritance:
